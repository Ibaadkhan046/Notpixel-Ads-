class Settings:
    USE_PROXY_FROM_FILE = False


settings = Settings()
